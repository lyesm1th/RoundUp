/* GeoZamir native Windows x64 GUI-subsystem bootstrap.
   The GUI itself lives in Windows PowerShell / Windows Forms.
   This EXE has no runtime dependency beyond normal Windows system DLLs. */
#include <stdint.h>

typedef uint16_t WCHAR;
typedef uint32_t DWORD;
typedef int BOOL;
typedef void *HANDLE;
typedef struct {
    DWORD cb;
    WCHAR *lpReserved;
    WCHAR *lpDesktop;
    WCHAR *lpTitle;
    DWORD dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars;
    DWORD dwFillAttribute, dwFlags;
    uint16_t wShowWindow, cbReserved2;
    uint8_t *lpReserved2;
    HANDLE hStdInput, hStdOutput, hStdError;
} STARTUPINFOW;
typedef struct {HANDLE hProcess, hThread; DWORD dwProcessId, dwThreadId;} PROCESS_INFORMATION;

extern void *__imp_GetModuleFileNameW;
extern void *__imp_CreateProcessW;
extern void *__imp_ExitProcess;
typedef __attribute__((ms_abi)) DWORD (*GetModuleFileNameWFn)(HANDLE, WCHAR*, DWORD);
typedef __attribute__((ms_abi)) BOOL (*CreateProcessWFn)(const WCHAR*, WCHAR*, void*, void*, BOOL, DWORD, void*, const WCHAR*, STARTUPINFOW*, PROCESS_INFORMATION*);
typedef __attribute__((ms_abi,noreturn)) void (*ExitProcessFn)(DWORD);
#define GET_MODULE_NAME ((GetModuleFileNameWFn)__imp_GetModuleFileNameW)
#define CREATE_PROCESS ((CreateProcessWFn)__imp_CreateProcessW)
#define EXIT_PROCESS ((ExitProcessFn)__imp_ExitProcess)

static WCHAR module_path[32768];
static WCHAR command_line[32768];
static STARTUPINFOW startup;
static PROCESS_INFORMATION process;

static unsigned append_ascii(WCHAR *out, unsigned pos, const char *s) {
    while (*s && pos < 32764) out[pos++] = (unsigned char)*s++;
    return pos;
}

void launcher_entry(void) {
    const DWORD length = GET_MODULE_NAME(0, module_path, 32768);
    if (!length || length >= 32760) EXIT_PROCESS(1);

    unsigned base_end = length;
    while (base_end && module_path[base_end - 1] != '\\' && module_path[base_end - 1] != '/') base_end--;
    if (!base_end) EXIT_PROCESS(1);

    unsigned pos = append_ascii(command_line, 0,
        "powershell.exe -NoProfile -Sta -ExecutionPolicy Bypass -WindowStyle Hidden -File \"");
    for (unsigned i = 0; i < base_end && pos < 32764; i++) command_line[pos++] = module_path[i];
    pos = append_ascii(command_line, pos, "launcher\\GeoZamir_Launcher.ps1\"");
    command_line[pos] = 0;
    module_path[base_end] = 0; /* Working directory: folder containing this EXE */

    startup.cb = sizeof(startup);
    if (!CREATE_PROCESS(0, command_line, 0, 0, 0, 0x08000000, 0,
                        module_path, &startup, &process)) EXIT_PROCESS(1);
    EXIT_PROCESS(0);
}
