/* Build-only stubs used to derive a kernel32 import library with GNU ld.
   This mock DLL must never be distributed. Windows supplies real kernel32. */
#include <stdint.h>
typedef uint16_t WCHAR;
typedef uint32_t DWORD;
typedef void* HANDLE;
__attribute__((ms_abi)) DWORD GetModuleFileNameW(HANDLE h, WCHAR *p, DWORD n) {return 0;}
__attribute__((ms_abi)) int CreateProcessW(const WCHAR *a, WCHAR *b, void *c, void *d, int e, DWORD f, void *g, const WCHAR *h, void *i, void *j) {return 0;}
__attribute__((ms_abi)) void ExitProcess(DWORD n) {for(;;){}}
